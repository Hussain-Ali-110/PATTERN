 package observer_eventsmanagenments.newpackage;

import java.io.File;

public class SMSSupportListener implements EventListener {
    private String phoneNumber;
    private String defaultSMS;

    public SMSSupportListener(String phoneNumber, String defaultSMS) {
        this.phoneNumber = phoneNumber;
        this.defaultSMS = defaultSMS;
    }

    @Override
    public void update(String eventType, File file) {
        if (defaultSMS.length() > 160) {
            System.out.println("Warning: SMS exceeds 160 characters. Please define a valid default SMS.");
        } else {
            System.out.println("Sending SMS to " + phoneNumber + ": " + defaultSMS);
        }
    }
}
